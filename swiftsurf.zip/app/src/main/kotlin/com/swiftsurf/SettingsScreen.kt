package com.swiftsurf

import androidx.compose.runtime.Composable
import androidx.compose.material3.Text

@Composable
fun SettingsScreen() {
    Text(text = "Settings")
}
