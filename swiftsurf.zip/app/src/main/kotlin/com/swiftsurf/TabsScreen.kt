package com.swiftsurf

import androidx.compose.runtime.Composable
import androidx.compose.material3.Text

@Composable
fun TabsScreen() {
    Text(text = "Tabs - Smart tabs will appear here")
}
