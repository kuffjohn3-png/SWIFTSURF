package com.swiftsurf.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class VPNConfigActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle s){ super.onCreate(s); setContentView(R.layout.activity_vpn_config); }
}
