package com.swiftsurf

import androidx.compose.runtime.Composable
import com.google.accompanist.web.WebView
import com.google.accompanist.web.rememberWebViewState
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier

@Composable
fun BrowserScreen() {
    val state = rememberWebViewState(url = "https://www.google.com")
    WebView(state = state, modifier = Modifier.fillMaxSize())
}
