package com.swiftsurf.script; public class UserScript { private String name; private String code; public UserScript(String n, String c){name=n;code=c;} public String getCode(){return code;} }
